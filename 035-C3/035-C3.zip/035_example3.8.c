#include<stdio.h>
int main()
{
	char a='B',b='O',c='Y';
	putchar(a);
	putchar(b);
	putchar(c);
	putchar('\n');
	return 0;
}
